package hr.fer.oprpp1.hw08.local;

public interface ILocalizationListener {
	
	public void localizationChanged();
}
