package hr.fer.oprpp1.hw08.jnotepadpp;

public interface ICaseTransform {

	public char changeCase(char c);
}
