package hr.fer.zemris.java.hw05.shell;

public enum ShellStatus {
	
	CONTINUE,
	TERMINATE
}
