package hr.fer.oprpp1.custom.scripting.elems;

public class Element {
	
	 /**
	 * @return empty String
	 */
	public String asText() {
		 return "";
	 }
}
