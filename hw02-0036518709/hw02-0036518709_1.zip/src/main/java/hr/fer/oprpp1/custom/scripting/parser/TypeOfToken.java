package hr.fer.oprpp1.custom.scripting.parser;

public enum TypeOfToken {
	
	FOR,
	EQUALS,
	END,
	CONTENT,
	TEXT,
	EOF
}
