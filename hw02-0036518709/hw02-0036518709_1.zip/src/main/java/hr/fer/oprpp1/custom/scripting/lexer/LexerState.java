package hr.fer.oprpp1.custom.scripting.lexer;

public enum LexerState {
	
	FOR,
	EQUALS,
	TEXT,
	TAG,
	END
}
