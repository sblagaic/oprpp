package hr.fer.oprpp1.custom.collections;

public interface Processor {
	
	public void process(Object value);
}
