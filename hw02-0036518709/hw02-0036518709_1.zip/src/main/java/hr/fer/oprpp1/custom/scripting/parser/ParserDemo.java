package hr.fer.oprpp1.custom.scripting.parser;

public class ParserDemo {
	
	public static void main(String[] args) {
		
	}
}
