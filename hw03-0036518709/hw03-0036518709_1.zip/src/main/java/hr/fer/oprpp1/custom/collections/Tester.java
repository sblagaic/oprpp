package hr.fer.oprpp1.custom.collections;

public interface Tester<T> {

	boolean test(T obj);
	
}
