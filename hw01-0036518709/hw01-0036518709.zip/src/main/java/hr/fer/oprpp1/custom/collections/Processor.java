package hr.fer.oprpp1.custom.collections;

public class Processor {
	
	public void process(Object value) {
		
	}
}
