package hr.fer.oprpp1.hw04.db;

public enum TokenType {
	
	ATTRIBUTE,
	OPERATOR,
	LITERAL,
	AND,
	LINE,
	EOF
}
