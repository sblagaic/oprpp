package hr.fer.zemris.java.gui.calc;

import java.awt.Component;

public interface ILayout {

	public double getLayoutSize(Component c);
}
