package hr.fer.zemris.java.gui.layouts;

import hr.fer.zemris.java.gui.calc.CalcModelImpl;

public interface IMiscAction {
	
	public void setAction(CalcModelImpl model);
}
