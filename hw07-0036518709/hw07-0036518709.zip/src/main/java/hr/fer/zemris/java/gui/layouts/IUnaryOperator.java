package hr.fer.zemris.java.gui.layouts;

public interface IUnaryOperator {

	public double calculate(double value);
	
}
